import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import BahtiyarTunaSite from './site/BahtiyarTunaSite';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BahtiyarTunaSite />
  </React.StrictMode>
);
